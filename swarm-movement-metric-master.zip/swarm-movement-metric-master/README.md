# swarm-movement-metric
Paper on metrics for the `internal' movement of swarms
